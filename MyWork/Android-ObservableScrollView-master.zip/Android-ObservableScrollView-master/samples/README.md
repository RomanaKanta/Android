# Samples

This sample project demonstrates how the Android-ObservableScrollView works.

This document's goal is to lead you to run the sample app and help understanding how to use this library.

Please note that this document is still work in progress.
Although I've built the app on Android Studio, Eclipse, Gradle on Mac and Gradle on Linux of Travis CI, there might be some implicit dependencies which I haven't noticed and you couldn't build it correctly.
Therefore I'd greatly appreciate it if you report it to me.

## How to build

### on Android Studio

TODO

### on Eclipse

TODO

### on Gradle

Windows:

```sh
> gradlew installDevDebug
```

Linux/Mac:

```sh
$ ./gradlew installDevDebug
```