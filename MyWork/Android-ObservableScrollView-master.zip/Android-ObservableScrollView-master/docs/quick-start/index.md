# Quick start

Thank you for having interest in this library!  
In this section, I'll show some quick instructions for introducing this library into your app.

1. [Dependencies](../../docs/quick-start/dependencies.md)
1. [Layout](../../docs/quick-start/layout.md)
1. [Animation codes](../../docs/quick-start/animation.md)

[Next: Dependencies &raquo;](../../docs/quick-start/dependencies.md)
