# Reference

1. [Supported widgets](../../docs/basic/supported-widgets.md)
1. [Environment](../../docs/reference/environment.md)
1. [Release notes](../../docs/reference/release-notes.md)
