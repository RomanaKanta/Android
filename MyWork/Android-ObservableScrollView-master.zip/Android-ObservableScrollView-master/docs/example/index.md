# Try the examples app

To understand how it works, let's see the existing example app
and check if there are some patterns you want to implement.

1. [Download from Google Play](../../docs/example/google-play.md)
1. [Download from wercker](../../docs/eaxmple/wercker.md)
1. [Build on Android Studio](../../docs/example/android-studio.md)
1. [Build on Eclipse](../../docs/example/eclipse.md)

[Next: Download from Google Play &raquo;](../../docs/example/google-play.md)
