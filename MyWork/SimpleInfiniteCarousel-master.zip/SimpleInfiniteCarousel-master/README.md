SimpleInfiniteCarousel
======================

A sample to show how to make a simple infinite carousel with ViewPager on Android

http://tech.leolink.net/2013/02/create-simple-infinite-carousel-in.html


======================
### Update on 2016/08/04
I'm glad this sample helped some forks out there.

Unfortunately I don't have much time to maintain/support this, please don't contact me directly, just create issues, I will might be able to fix them at some point in the future.
